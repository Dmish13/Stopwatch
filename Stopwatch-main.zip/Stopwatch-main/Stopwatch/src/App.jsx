import Stopwatch from "./Stopwatch.jsx"
function App() {
  return(<Stopwatch/>)
}

export default App
