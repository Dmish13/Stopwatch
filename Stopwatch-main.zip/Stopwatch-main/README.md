# Stopwatch
Stopwatch Program in React
![Screenshot 2025-06-13 150445](https://github.com/user-attachments/assets/eabf52fe-e424-4ecb-abf9-bd0e4f0c3032)

Video Demo: 
https://github.com/user-attachments/assets/6eb9abc2-f3f8-4e6e-9f0b-3e63e3858cee

Base Code from Bro Code: https://youtu.be/CgkZ7MvWUAA?si=HZZPx8WcRnbvs_Kn&t=15781

Modified by adding a lap feature to the stopwatch
